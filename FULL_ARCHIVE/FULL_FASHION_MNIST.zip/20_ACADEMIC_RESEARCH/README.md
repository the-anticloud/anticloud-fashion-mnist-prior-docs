# 20 Academic Research

**Project:** FASHION_MNIST
**Upstream:** https://github.com/zalandoresearch/fashion-mnist

Content specific to FASHION_MNIST in category CLOTHING_RETAIL.
